# Virtus Strategic Education Group

Elite, PhD-level educational consulting with AI-powered guidance.

## Deployment

Deployed on Vercel with custom domain virtus-edu.net.
